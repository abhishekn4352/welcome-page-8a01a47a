import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboardnew',
  templateUrl: './dashboardnew.component.html',
  styleUrls: ['./dashboardnew.component.scss']
})
export class DashboardnewComponent {

}
