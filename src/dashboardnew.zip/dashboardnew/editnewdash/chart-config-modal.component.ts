import { Component } from '@angular/core';

@Component({
  selector: 'app-chart-config-modal',
  templateUrl: './chart-config-modal.component.html',
  styleUrls: ['./chart-config-modal.component.scss']
})
export class ChartConfigModalComponent {
  // This component will be used to display the chart configuration manager in a modal
}