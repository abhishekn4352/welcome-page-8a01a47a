import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dynamicform',
  templateUrl: './dynamicform.component.html',
  styleUrls: ['./dynamicform.component.scss']
})
export class DynamicformComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
